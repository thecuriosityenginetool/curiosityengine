// src/background.ts
chrome.runtime.onInstalled.addListener(() => {
  console.log("Sales Curiosity Extension installed");
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "PING_API") {
    const headers = {
      "Content-Type": "application/json"
    };
    if (message.authToken) {
      headers["Authorization"] = `Bearer ${message.authToken}`;
    }
    fetch(message.url, {
      method: message.method || "GET",
      headers,
      body: message.body ? JSON.stringify(message.body) : void 0
    }).then(async (res) => {
      const data = await res.json().catch(() => ({}));
      sendResponse({ ok: res.ok, status: res.status, data });
    }).catch((err) => {
      sendResponse({ ok: false, error: String(err) });
    });
    return true;
  }
});
//# sourceMappingURL=background.js.map
