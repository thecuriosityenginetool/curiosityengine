// src/auth-bridge.ts
window.addEventListener("message", async (event) => {
  if (event.origin !== "https://www.curiosityengine.io" && event.origin !== "http://localhost:3000") {
    console.log("\u{1F535} Auth bridge: Ignoring message from", event.origin);
    return;
  }
  console.log("\u{1F535} Auth bridge: Received message:", event.data.type);
  if (event.data.type === "EXTENSION_AUTH" && event.data.authToken) {
    console.log("\u{1F535} Auth bridge: Received auth data from web page");
    console.log("\u{1F535} Auth bridge: Auth token:", event.data.authToken.substring(0, 20) + "...");
    console.log("\u{1F535} Auth bridge: User:", event.data.user);
    try {
      await chrome.storage.local.set({
        authToken: event.data.authToken,
        user: event.data.user
      });
      console.log("\u2705 Auth bridge: Token stored in extension");
      const stored = await chrome.storage.local.get(["authToken", "user"]);
      console.log("\u2705 Auth bridge: Verified storage:", !!stored.authToken, !!stored.user);
      window.postMessage({
        type: "EXTENSION_AUTH_SUCCESS",
        success: true
      }, event.origin);
    } catch (error) {
      console.error("\u274C Auth bridge: Error storing token:", error);
      window.postMessage({
        type: "EXTENSION_AUTH_ERROR",
        error: String(error)
      }, event.origin);
    }
  }
});
console.log("\u{1F535} Auth bridge: Content script loaded");
window.postMessage({ type: "EXTENSION_BRIDGE_READY" }, window.location.origin);
//# sourceMappingURL=auth-bridge.js.map
