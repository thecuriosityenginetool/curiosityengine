// src/content.ts
console.debug("Sales Curiosity content script loaded");
function extractLinkedInProfile() {
  console.log("\u{1F50D} Starting LinkedIn profile extraction...");
  console.log("\u{1F4CD} Current URL:", window.location.href);
  const profileData = {
    url: window.location.href,
    scrapedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  const allH1s = document.querySelectorAll("h1");
  console.log("Found H1 elements:", allH1s.length);
  allH1s.forEach((h1, i) => {
    console.log(`H1 ${i}:`, h1.textContent?.trim().substring(0, 100));
  });
  for (const h1 of allH1s) {
    const text = h1.textContent?.trim();
    if (text && text.length > 2 && text.length < 100) {
      profileData.name = text;
      console.log("\u2705 Found name:", profileData.name);
      break;
    }
  }
  const mainSelectors = ["main", '[role="main"]', "#main-content", "body"];
  let mainContent = null;
  for (const selector of mainSelectors) {
    mainContent = document.querySelector(selector);
    if (mainContent) {
      console.log("\u2705 Found main content with selector:", selector);
      break;
    }
  }
  if (mainContent) {
    const fullText = mainContent.textContent?.trim() || "";
    profileData.fullPageText = fullText.substring(0, 2e4);
    console.log("\u2705 Extracted full page text length:", profileData.fullPageText.length);
    console.log("\u{1F4C4} First 200 chars:", profileData.fullPageText.substring(0, 200));
  } else {
    console.error("\u274C Could not find main content element!");
    profileData.fullPageText = document.body.textContent?.trim().substring(0, 2e4) || "";
    console.log("\u26A0\uFE0F Using body text as fallback:", profileData.fullPageText.length, "chars");
  }
  const headlineElements = document.querySelectorAll('[class*="body-medium"]');
  console.log("Found potential headline elements:", headlineElements.length);
  for (const elem of headlineElements) {
    const text = elem.textContent?.trim();
    if (text && text.length > 10 && text.length < 200 && text !== profileData.name) {
      profileData.headline = text;
      console.log("\u2705 Found headline:", profileData.headline);
      break;
    }
  }
  const locationElements = document.querySelectorAll('[class*="body-small"]');
  for (const elem of locationElements) {
    const text = elem.textContent?.trim();
    if (text && text.length > 3 && text.length < 100 && !text.includes("followers") && !text.includes("connections")) {
      profileData.location = text;
      console.log("\u2705 Found location:", profileData.location);
      break;
    }
  }
  const sections = ["about", "experience", "education", "skills"];
  sections.forEach((sectionId) => {
    const section = document.getElementById(sectionId);
    if (section) {
      const container = section.closest("section");
      if (container) {
        const text = container.textContent?.trim().substring(0, 3e3);
        profileData[sectionId + "Section"] = text;
        console.log(`\u2705 Found ${sectionId} section:`, text?.length, "chars");
      }
    }
  });
  const hasData = profileData.name || profileData.headline || profileData.fullPageText && profileData.fullPageText.length > 100;
  console.log("\u{1F3AF} Extraction complete. Has usable data:", hasData);
  console.log("\u{1F4CA} Final profile data summary:", {
    name: profileData.name ? "\u2705" : "\u274C",
    headline: profileData.headline ? "\u2705" : "\u274C",
    location: profileData.location ? "\u2705" : "\u274C",
    fullTextLength: profileData.fullPageText?.length || 0,
    aboutSection: profileData.aboutSection ? "\u2705" : "\u274C",
    experienceSection: profileData.experienceSection ? "\u2705" : "\u274C",
    educationSection: profileData.educationSection ? "\u2705" : "\u274C"
  });
  return profileData;
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "EXTRACT_LINKEDIN_PROFILE") {
    try {
      const profileData = extractLinkedInProfile();
      sendResponse({ success: true, data: profileData });
    } catch (error) {
      sendResponse({ success: false, error: String(error) });
    }
    return true;
  }
  if (message.type === "HIGHLIGHT_LINKS") {
    document.querySelectorAll("a").forEach((a) => {
      a.style.outline = "2px solid #22c55e";
    });
  }
});
//# sourceMappingURL=content.js.map
